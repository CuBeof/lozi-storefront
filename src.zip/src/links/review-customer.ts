import { defineLink } from "@medusajs/framework/utils"
import reviewModule from "../modules/product-review"
import CustomerModule from "@medusajs/medusa/customer"

export default defineLink(
  {
    linkable: reviewModule.linkable.review,
    field: "customer_id",
    isList: false,
  },
  CustomerModule.linkable.customer,
  {
    readOnly: true
  }
)