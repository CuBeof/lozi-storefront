import {
  createStep,
  createWorkflow,
  WorkflowResponse,
  StepResponse,
} from "@medusajs/framework/workflows-sdk"

import { PRODUCT_REVIEW_MODULE } from "../../../modules/product-review";
import reviewModuleService from "../../../modules/product-review/service";


type reviewInput = {
    product_id: string;
    customer_id: string;
    rating: number;
    content: string;
    images: string[];
}

export const createreviewStep = createStep(
  "create-review",
  async (payload : reviewInput, { container }) => {
    const reviewService: reviewModuleService = container.resolve(PRODUCT_REVIEW_MODULE)
    const review = await reviewService.createProductReviews(payload)

    return new StepResponse(review, { reviewId: review.id })
  },

  // Roll back
  async (reviewId, { container }) => {
    if (!reviewId) {
      return
    }

    const reviewModuleService: reviewModuleService = container.resolve(
      PRODUCT_REVIEW_MODULE
    )

    await reviewModuleService.deleteProductReviews(reviewId)
  }
)

