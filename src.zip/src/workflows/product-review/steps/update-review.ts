import {
  createStep,
  StepResponse,
} from "@medusajs/framework/workflows-sdk"
import { PRODUCT_REVIEW_MODULE } from "../../../modules/product-review"
import reviewModuleService from "../../../modules/product-review/service"


export type UpdateReviewsStepInput = {
  id: string
  status: "pending" | "approved" | "rejected"
}[]

export const updateReviewsStep = createStep(
  "update-review",
  async (input: UpdateReviewsStepInput, { container }) => {
    const reviewModuleService: reviewModuleService = container.resolve(
      PRODUCT_REVIEW_MODULE
    )

    // Get original review before update
    const originalReviews = await reviewModuleService.listProductReviews({
      id: input.map((review) => review.id)
    })

    const reviews = await reviewModuleService.updateProductReviews(input)

    return new StepResponse(reviews, originalReviews)
  },
  async (originalReviews, { container }) => {
    if (!originalReviews) {
      return
    }

    const reviewModuleService: reviewModuleService = container.resolve(
      PRODUCT_REVIEW_MODULE
    )

    // Restore original review status
    const formattedReviews = originalReviews.map((review) => ({
      id: review.id,
      product_id: review.product_id,
      customer_id: review.customer_id,
      rating: review.rating,
      content: review.content,
      status: review.status,
      created_at: review.created_at,
      updated_at: review.updated_at,
    }))
    await reviewModuleService.updateProductReviews(formattedReviews)
  }
)



