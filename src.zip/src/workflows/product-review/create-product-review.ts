import { createWorkflow, WorkflowResponse, transform } from "@medusajs/framework/workflows-sdk"
import { useQueryGraphStep, uploadFilesWorkflow } from "@medusajs/medusa/core-flows"
import { createreviewStep } from "./steps/create-review"


type CreateReviewInput = {
  content: string
  rating: number
  product_id: string
  customer_id: string
  files?: { originalname: string; mimetype: string; buffer: Buffer }[]
  access?: "public" | "private"
}

export const createReviewWorkflow = createWorkflow("create-review", (input: CreateReviewInput) => {
  // 1) Ensure product exists
  useQueryGraphStep({
    entity: "product",
    fields: ["id"],
    filters: { id: input.product_id },
    options: { throwIfKeyNotFound: true },
  }) // (pattern from reviews tutorial) (["Add createReviewWorkflow"](https://docs.medusajs.com/resources/how-to-tutorials/tutorials/product-reviews#add-createreviewworkflow))

  // 2) Prepare files with transform
  const filesForUpload = transform({ input }, ({ input }) =>
    Array.isArray(input.files)
      ? input.files.map((f) => ({
          filename: f.originalname,
          mimeType: f.mimetype,
          content: f.buffer.toString("binary"),
          access: input.access ?? "public",
        }))
      : []
  )

  // 3) Upload (nested workflow)
  const uploadedFiles = uploadFilesWorkflow.runAsStep({ input: { files: filesForUpload } }) || []

  // 4) Create review with image IDs
  const review = createreviewStep(
    transform({ input, uploadedFiles }, ({ input, uploadedFiles }) => ({
      product_id: input.product_id,
      customer_id: input.customer_id,
      rating: input.rating,
      content: input.content,
      images: uploadedFiles.map((f) => f.id),
    }))
  )

  return new WorkflowResponse({ review })
})