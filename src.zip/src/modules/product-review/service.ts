import { MedusaService } from "@medusajs/framework/utils"
import { ProductReview, ProductReviewImage } from "./models"

class reviewModuleService extends MedusaService({ ProductReview, ProductReviewImage }) { }

export default reviewModuleService
