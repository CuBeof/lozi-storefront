import { Module } from "@medusajs/framework/utils"
import reviewModuleService from "./service"

export const PRODUCT_REVIEW_MODULE = "review"

export default Module(PRODUCT_REVIEW_MODULE, {
  service: reviewModuleService,
})
