import { model } from "@medusajs/framework/utils"
import { ProductReviewImage } from "./product-review-image"

export const ProductReview = model.define("review", {
    id: model.id().primaryKey(),
    product_id: model.text(),
    customer_id: model.text(),
    rating: model.number(),
    content: model.text(),
    status: model.enum(["pending", "approved", "rejected"]).default("pending"),
    images: model.hasMany(() => ProductReviewImage, { mappedBy: "review" }),
    test: model.text()
}).checks([
    {
        name: "rating_range",
        expression: (columns) => `${columns.rating} >= 1 AND ${columns.rating} <= 5`,
    }
])
