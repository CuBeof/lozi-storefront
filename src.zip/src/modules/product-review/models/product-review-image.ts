import { model } from "@medusajs/framework/utils"
import { ProductReview } from "./product-review"

export const ProductReviewImage = model.define("review_image", {
    id: model.id().primaryKey(),
    url: model.text(),
    review: model.belongsTo(() => ProductReview, { mappedBy: "images" }),
})
